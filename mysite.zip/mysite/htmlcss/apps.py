from django.apps import AppConfig


class HtmlcssConfig(AppConfig):
    name = 'htmlcss'
